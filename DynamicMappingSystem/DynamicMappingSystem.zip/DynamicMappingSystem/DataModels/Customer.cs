﻿namespace DynamicMappingSystem.DataModels
{
    public class Customer
    {
        public string Name { get; set; }
    }
}

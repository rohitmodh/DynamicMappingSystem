﻿namespace DynamicMappingSystem.Exceptions
{
    public class ValidationMappingException : Exception
    {
        public ValidationMappingException(string message) : base(message) { }
    }
}

﻿namespace DynamicMappingSystem.Validation
{
    public class FluentValidator : IModelValidator
    {
        public List<string> Validate(object model)
        {
            return new List<string>(); // Stub, implement FluentValidation logic
        }
    }
}

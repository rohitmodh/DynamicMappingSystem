﻿using DynamicMappingSystem.Mapping;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace DynamicMappingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MappingsController : ControllerBase
    {
        private readonly IMapHandler _mapHandler;

        public MappingsController(IMapHandler mapHandler)
        {
            _mapHandler = mapHandler;
        }

        [HttpPost("map")]
        public IActionResult Map([FromBody] MapRequest request)
        {
            var result = _mapHandler.Map(request.Data, request.SourceType, request.TargetType);
            return Ok(result);
        }
    }
}

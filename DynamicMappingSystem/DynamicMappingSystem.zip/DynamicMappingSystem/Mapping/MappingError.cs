﻿namespace DynamicMappingSystem.Mapping
{
    public class MappingError
    {
        public string Code { get; set; } = default!;
        public string Message { get; set; } = default!;
    }
}

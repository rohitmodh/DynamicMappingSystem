﻿using System.ComponentModel.DataAnnotations;

namespace DynamicMappingSystem.Mapping
{
    public abstract class BaseMapHandler : IMapHandler
    {
        public MappingResult Map(object data, string sourceType, string targetType, string? version = null)
        {
            var result = new MappingResult();
            try
            {
                ValidateInput(data, sourceType);
                var mapped = PerformMapping(data, sourceType, targetType, version);
                ValidateOutput(mapped, targetType);
                result.Success = true;
                result.MappedData = mapped;
            }
            catch (ValidationException ex)
            {
                result.Errors.Add(new MappingError { Code = MappingErrorCodes.ValidationFailed, Message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                result.Errors.Add(new MappingError { Code = MappingErrorCodes.MappingRuleNotFound, Message = ex.Message });
            }
            catch (ApplicationException ex)
            {
                result.Errors.Add(new MappingError { Code = MappingErrorCodes.PropertyMappingFailed, Message = ex.Message });
            }
            catch (Exception ex)
            {
                result.Errors.Add(new MappingError { Code = MappingErrorCodes.UnexpectedError, Message = ex.Message });
            }
            return result;
        }

        //protected abstract void ValidateInput(object data, string sourceType);
        //protected abstract object PerformMapping(object data, string sourceType, string targetType, string? version);
        //protected abstract void ValidateOutput(object mappedData, string targetType);

        protected abstract void ValidateInput(object data, string sourceType);
        protected abstract object PerformMapping(object data, string sourceType, string targetType, string? version);
        protected abstract void ValidateOutput(object result, string targetType);
        protected abstract void HandleError(Exception ex, string sourceType, string targetType);
        protected virtual void Log(string message) => Console.WriteLine($"[LOG] {message}");
    }
}

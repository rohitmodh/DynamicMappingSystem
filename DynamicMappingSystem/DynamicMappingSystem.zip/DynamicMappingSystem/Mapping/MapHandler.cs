﻿using DynamicMappingSystem.Exceptions;
using DynamicMappingSystem.Providers;
using FluentValidation;
using System.ComponentModel.DataAnnotations;

namespace DynamicMappingSystem.Mapping
{
    public class MapHandler : BaseMapHandler
    {
        private readonly IDictionary<string, IValidator> _validators;
       // private readonly IDictionary<string, Func<object, object>> _converters;
        private readonly List<MapperRule> _rules;

        public MapHandler(
            IDictionary<string, IValidator> validators,
            IDictionary<string, Func<object, object>> converters,
            IMappingRuleProvider ruleProvider)
        {
            _validators = validators;
            //_converters = converters;
            _rules = ruleProvider.GetRules();
        }

        protected override void ValidateInput(object data, string sourceType)
        {
            if (_validators.TryGetValue(sourceType, out var validator))
            {
                var result = validator.Validate(new ValidationContext<object>(data));
                if (!result.IsValid) throw new FluentValidation.ValidationException(result.Errors);
            }
        }

        protected override object PerformMapping(object data, string sourceType, string targetType, string? version)
        {
            var rule = _rules.FirstOrDefault(r => r.SourceType == sourceType && r.TargetType == targetType && (version == null || r.Version == version));
            if (rule == null)
                throw new InvalidOperationException($"No mapping rule found for {sourceType} -> {targetType} (version: {version ?? "latest"})");

            var targetTypeObj = Type.GetType(targetType) ?? throw new InvalidOperationException($"Target type '{targetType}' not found");
            var targetInstance = Activator.CreateInstance(targetTypeObj);

            foreach (var propMap in rule.PropertyMappings)
            {
                var sourceProp = data.GetType().GetProperty(propMap.SourceProperty);
                var targetProp = targetTypeObj.GetProperty(propMap.TargetProperty);

                if (sourceProp == null || targetProp == null) continue;

                var value = sourceProp.GetValue(data);
                //if (!string.IsNullOrWhiteSpace(propMap.CustomConverter) && _converters.TryGetValue(propMap.CustomConverter, out var converter))
                //{
                //    value = converter(value);
                //}
                targetProp.SetValue(targetInstance, value);
            }
            return targetInstance!;
        }

        protected override void ValidateOutput(object result, string targetType)
        {
            if (_validators.TryGetValue(targetType, out var validator))
            {
                var validation = validator.Validate(new ValidationContext<object>(result));
                if (!validation.IsValid) throw new FluentValidation.ValidationException(validation.Errors);
            }
        }
        protected override void HandleError(Exception ex, string sourceType, string targetType)
        {
            Console.Error.WriteLine($"[ERROR] Mapping {sourceType} → {targetType} failed: {ex.Message}");
        }
    }
}

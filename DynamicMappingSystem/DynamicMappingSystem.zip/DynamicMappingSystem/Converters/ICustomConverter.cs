﻿namespace DynamicMappingSystem.Converters
{
    public interface ICustomConverter
    {
        object Convert(object source);
    }
}

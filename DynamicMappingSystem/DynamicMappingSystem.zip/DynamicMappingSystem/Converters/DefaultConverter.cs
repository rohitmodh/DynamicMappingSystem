﻿namespace DynamicMappingSystem.Converters
{
    public class DefaultConverter : ICustomConverter
    {
        public object Convert(object source) => source;
    }
}
